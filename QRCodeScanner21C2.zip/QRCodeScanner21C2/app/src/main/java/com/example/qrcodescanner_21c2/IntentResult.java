package com.example.qrcodescanner_21c2;

public interface IntentResult {
}
